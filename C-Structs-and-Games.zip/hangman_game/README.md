# Hangman Game

This project implements a simplified version of the classic Hangman word-guessing game in C.

## How It Works
- Player 1 inputs a secret word.
- Player 2 guesses one letter at a time.
- Incorrect guesses reduce the attempt counter.
- Correct guesses reveal the letters in position.
- Game ends when the word is guessed or attempts run out.

## Compilation
```bash
gcc hangman_game.c -o hangman_game
./hangman_game
```