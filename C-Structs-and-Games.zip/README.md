# C Structs and Games

This repository contains a collection of small educational C projects demonstrating use of structs, data structures, and game logic.

## Projects

- [Hangman Game](./hangman_game/README.md)
- [Linked Queue](./linked_queue/README.md)
- [Turn-Based Strategy Game](./strategy_game/README.md)
