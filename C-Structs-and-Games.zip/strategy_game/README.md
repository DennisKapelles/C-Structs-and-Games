# Turn-Based Strategy Game

A two-player console-based strategy game where players buy units and manage resources.

## Features
- Struct-based unit system
- Worker/military unit types
- Win condition: higher army or wealth

## Compilation
```bash
gcc strategy_game.c -o strategy_game
./strategy_game
```