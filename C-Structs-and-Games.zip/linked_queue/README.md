# Linked List Queue

Implements a FIFO queue using a singly linked list in C.

## Features
- Insert at the end
- Delete from the front
- Get Nth element
- Count occurrences of a value

## Compilation
```bash
gcc linked_queue.c -o linked_queue
./linked_queue
```