#include<stdio.h>
#include <ctype.h>

#define MAXLENGTH 20

/* createHistogram is a function that increments x when a word with length x is found */
/* for example :
                    wordLength is 10 the 10th slot will increment by 1
                    if a word has a length bigger than 20 then it goes to the last spot
                        reserved for wordLength>20
*/
int createHistogram(int anArray[], int length);

/* printHistogram is a function that prints the histogram */
int printHistogram(int anArray[], int size);

int main(void){

    char letters;
    int histoArray[MAXLENGTH+1];
    int i,j;
    int countLetter = 0;

    for(i=0; i<=MAXLENGTH; i++){
        histoArray[i] = 0;
    }

    printf("Please insert a text : ");

    while((letters = getchar()) != EOF){
        if((letters == ' ')|| letters=='\n') {
            createHistogram(histoArray, countLetter);
            countLetter = 0;
        }else{
            if(isalnum(letters)){
                countLetter += 1;
            }
        }
    }
    /* This line is to catch the last word before the enter */
    createHistogram(histoArray, countLetter);

    printHistogram(histoArray, MAXLENGTH);

    return 0;

}

int createHistogram(int anArray[], int length){

    if(length <= MAXLENGTH){

        anArray[length-1] += 1;

    }else{

        anArray[MAXLENGTH] += 1;

    }

    return 0;

}

int printHistogram(int anArray[], int size){

    int i,j;

    printf("Word Length \t|Number of Occurrances\n\n");
    for(i=0; i<size; i++){

        printf("%d \t\t|",i+1);
        /* Find if there are words in the histoArray */
        if(anArray[i] != 0){
            /* If there are then print stars */
            for(j=0; j<anArray[i]; j++){
                printf("*");
            }
        }

        printf("\n");


    }
    /* Print start for the words longer than 20 */
    printf(">20 \t\t|");
    for(j=0; j<anArray[size]; j++){
        printf("*");
    }
    printf("\n");

    return 0;

}
