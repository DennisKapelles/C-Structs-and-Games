#include <stdio.h>
#include <stdlib.h>

int **create2DArray(int nrows, int ncolumns);
void fillArrayWithValues(int **array, int nrows, int ncolumns);
int *sumOverArrayRows(int **array, int nrows, int ncolumns);

int main(){
  int i, nrows, ncolumns;
  int *resultsArray;
  int **arrayOfIntegerPointers;

  /* xreiazontai oi metavlhtes autes an epileksoume thn yloipoihsh pou yparxei stis grammes 38-49
  int **rowPointer;
  int *columnPointer;
  */


  printf("Parakalw dwste poses grammes tha exei o pinakas: ");
  scanf("%d", &nrows);

  printf("Parakalw dwste poses sthles tha exei o pinakas: ");
  scanf("%d", &ncolumns);



  /* Ston sxoliasmeno kwdika yparxei h idia leitourgeia pou ginetai kai stis grammes 30-35 
   * 
   * OI dyo yloipoihseis eiani isodynames alla sth deuterh exoume mono xrhsh pointers gia 
   * gia thn prospelash twn stoixeiwn tou dysdiastatou pinaka.
   * 
   *
  for(rowPointer = arrayOfIntegerPointers, i=0; rowPointer <= rowPointer+nrows-1; rowPointer++){
    for(columnPointer = *rowPointer, k=0; columnPointer <= *rowPointer + ncolumns-1; columnPointer++){
      printf("Dwse arithmo gia to stoixeio (%d,%d) tou pinaka: ",  i+1,k+1);
      scanf("%d", columnPointer);
    }
  }
   */
  arrayOfIntegerPointers = create2DArray(nrows, ncolumns);
  fillArrayWithValues(arrayOfIntegerPointers,nrows, ncolumns);
  resultsArray = sumOverArrayRows(arrayOfIntegerPointers, nrows , ncolumns);
  for( i = 0; i< nrows; i++){
      printf("To athroisma twn timwn tis grammis %d einai: %d \n", i+1, resultsArray[i]);
  }  

  return 0;

}
/* dhmiourgia dysdiastatou pinaka me xrhsh pointers */
int **create2DArray(int nrows, int ncolumns){
  int **arrayOfIntegerPointers  = (int **) malloc(nrows*sizeof(int *));
  int i;

  for( i = 0; i< nrows; i++){
    arrayOfIntegerPointers[i] = (int *) malloc(ncolumns*sizeof(int));
  }
  return arrayOfIntegerPointers;
}

void fillArrayWithValues(int **array, int nrows, int ncolumns){

  int **rowIndex;
  int *columnIndex;
  int i,k;
  
  for(rowIndex = array, i=0; rowIndex <= (array+nrows)-1; rowIndex++, i++){
    for(columnIndex = *rowIndex, k=0; columnIndex <= *rowIndex + ncolumns-1; columnIndex++,k++){
      printf("Dwse arithmo gia to stoixeio (%d,%d) tou pinaka: ",  i+1,k+1);
      scanf("%d", columnIndex);
    }
  }
}

int *sumOverArrayRows(int ** array, int nrows, int ncolumns){

  int *row;
  int i,j;
  int *results = malloc(nrows*sizeof(int));
  
  for(i =0; i< nrows; i++){
    results[i] = 0;
    for(j = 0; j < ncolumns; j ++){
      results[i] += *(array[i]+j);
    }

  }
  return results;
}


/* enallaktikh yloipoihsh mono me deiktes
int *sumOverArrayRows(int **array, int nrows, int ncolumns){
  
  int **rowIndex;
  int *columnIndex;
  int *results,*i;

  results = malloc(nrows*sizeof(int));

  for(rowIndex = array,*result= 0, i =0 ; rowIndex <= array+nrows-1; rowIndex++, i++, result++){
    
    for(columnIndex = *rowIndex; columnIndex<= (*rowIndex)+ncolumns-1; columnIndex++){

      results[i] += (*columnIndex);

    }
  }
  return results;
}
*/
