#include <stdio.h>
#define N 100

int main()
{
	int table[N]; int i,j, flag, count=0;
	
	printf("Give values: ");
	
	for (i=0; i<N; i++) scanf("%d", &table[i]);
	
	for (i=0; i<N; i++)
	{
		flag=0;
		for (j=0; j<i; j++) if (table[i]==table[j]) {flag=1; break;}
		if (!flag) for(j=i+1; j<N; j++) if (table[i]==table[j])  count++;
    }

   printf("The number of repetitions is %d \n", count);
	
}
